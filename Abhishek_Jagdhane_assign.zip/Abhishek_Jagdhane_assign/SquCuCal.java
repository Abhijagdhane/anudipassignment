package Run;

import java.util.Scanner;

interface Printable    
{
	public void square();   
}

interface Calculate
{
	public void cube();
}

class Square1 implements Printable 
{
	 public void square()
	 {   
         Scanner s = new Scanner(System.in);
		 
		 System.out.println("Enter Number for square:");
		 int a= s.nextInt();
		 int c= a*a;                    
		 System.out.println("Squre of "+a+" is "+c);
	 }
}

class Cube1 implements Calculate
{
	public void cube()
	{ 
		 Scanner s = new Scanner(System.in);
		 
		 System.out.println("Enter Number for cube:");
		 int a= s.nextInt();
		 int c= a*a*a;
		 System.out.println("Cube of "+a+" is "+c);
	}
}

public class Q4SqCu
{
   public static void main(String[] args)
   {
	   Square1 s1= new Square1();
	   s1.square();
	   
	   Cube1 c1= new Cube1();
	   c1.cube();
			   
   }
}

